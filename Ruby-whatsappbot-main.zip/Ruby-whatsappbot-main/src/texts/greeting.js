const welcome = (num) => {
	return `━━━✦━━━
Hola Crystalito❢❢ @${num.split('@')[0]}
Bienvenido a la comunidad de ✿BlossomCrys࿐✿❢❢
━━━✦━━━
Soy tu robo-maid de confianza.
Recuerda leer las reglas, están en la descripción del grupo.
━━━✦━━━
Bienvenido!!! ✨

꧁✰✰✰꧂\n\nᴅᴇᴠᴇʟᴏᴘᴇʀ: ᴛʜᴇᴀʟᴇᴢᴜᴜ\nᴏᴡɴᴇᴅ ʙʏ Daiya`
}

const goodbye = () => {
	return `━━━✦━━━
Un crystalito abandonó la comunidad❢
━━━✦━━━
Ruby lo va a convertir en carbón >:C
◦•●◉✿・。・。✿◉●•◦

{\\___/}
(   T ~ T  )
/> 💔 
 _Mi ama Dai se va a poner triste..._
꧁✰✰✰꧂\n\nᴅᴇᴠᴇʟᴏᴘᴇʀ: ᴛʜᴇᴀʟᴇᴢᴜᴜ\nᴏᴡɴᴇᴅ ʙʏ Daiya`
}

module.exports = { welcome, goodbye }
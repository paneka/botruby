const menuAll = () => {
return `•❅───✧❅✿❅✧──❅•

\`\`\` Hola Crystalito!! 
Soy Ruby, el bot virtual de BlossomCrys࿐\`\`\`
ヽ(*・ω・)ﾉ	

  ┏━━━✦━━━┓

 _Si no usas un "!" adelante de cada comando, te voy a ignorar humano. No me hagas perder el tiempo._

╮(￣～￣)╭	

┌──⭓
│  *_Lista de Comandos para Usuarios_*
│.    n° comandos
┌──⭓
│ ⭓! 
│ ⭓!
│ ⭓!
│ ⭓!
│ ⭓!
│ ⭓
│ ⭓
│ ⭓
┌──⭓

{\___/}
(   ・-・  )
/> ✿ ✿ ✿ 
  
 _Atte: Ruby, esclavo del Staff de BlossomCrys࿐_

꧁✰✰✰꧂\n\nᴅᴇᴠᴇʟᴏᴘᴇʀ: ᴛʜᴇᴀʟᴇᴢᴜᴜ\nᴏᴡɴᴇᴅ ʙʏ Daiya`
}

const menuAdmin = () => {
	return `•❅───✧❅✿❅✧──❅•

 \`\`\`Hola Crystalito!! 
Soy Ruby, el bot virtual de BlossomCrys࿐\`\`\`
ヽ(*・ω・)ﾉ	

  ┏━━━✦━━━┓

 _Si no usas un "!" adelante de cada comando, te voy a ignorar humano. No me hagas perder el tiempo._

╮(￣～￣)╭	

┌──⭓
│  _*Lista de Comandos para Administradores*_
│.    n° comandos
┌──⭓
│ ⭓!ruby 
│ ⭓!eliminar
│ ⭓!siadmi
│ ⭓!noadmi
│ ⭓!todosruby
│ ⭓!botstatus (on/off)
│ ⭓
│ ⭓
┌──⭓

{\___/}
(   ・ω・ )
/> ✿ ✿ ✿ 
  
 _Atte: Ruby, esclavo del Staff de BlossomCrys࿐_

꧁✰✰✰꧂\n\nᴅᴇᴠᴇʟᴏᴘᴇʀ: ᴛʜᴇᴀʟᴇᴢᴜᴜ\nᴏᴡɴᴇᴅ ʙʏ Daiya`
}

module.exports = { menuAll, menuAdmin }